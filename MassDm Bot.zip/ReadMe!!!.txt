Install the Required Libraries:

"pip install discord.py"

Bot Needs to be in only 1 Server or it won´t work.