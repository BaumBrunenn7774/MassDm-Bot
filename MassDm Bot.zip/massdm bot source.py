import discord
from discord.ext import commands

# Setting up intents
intents = discord.Intents.default()
intents.members = True  # Allows the bot to access member information
intents.message_content = True  # Allows the bot to read message content

bot = commands.Bot(command_prefix='!', intents=intents)

@bot.event
async def on_ready():
    print(f'{bot.user} has connected to Discord!')
    
    # Loop through all the guilds the bot is in
    for guild in bot.guilds:
        # Loop through all the members in the guild
        for member in guild.members:
            if not member.bot:  # Avoid sending messages to other bots
                try:
                    # Try to send a direct message to the member
                    await member.send("Hello! This is an automatic message because the bot just turned on.") # Your custom message
                except discord.Forbidden:
                    print(f"Cannot send message to {member.name} (Forbidden).")
                except Exception as e:
                    print(f"Failed to send message to {member.name}: {e}")

# Start the bot with your token
bot.run('Your_Bot_Token')  # Replace with your actual bot token

# https://discord.gg/5Vk24S3867